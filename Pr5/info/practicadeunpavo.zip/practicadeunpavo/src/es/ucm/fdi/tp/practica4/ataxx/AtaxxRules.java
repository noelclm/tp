package es.ucm.fdi.tp.practica4.ataxx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.Utils;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.basecode.bgame.model.FiniteRectBoard;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Pair;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;


/**
 * Reglas del juego Ataxx.
 *
 */
public class AtaxxRules implements GameRules {

	protected final Pair<State, Piece> gameInPlayResult = new Pair<State, Piece>(State.InPlay, null);
	private int rows;
	private int cols;
	private int obstacles;
	
	/**
	 * La constructora de la clase AtaxxRules
	 * @param r = numero de filas
	 * @param c = numero de columnas
	 * @param obs = numero de obstaculos
	 */
	public AtaxxRules(int r, int c, int obs) {
		this.rows = r;
		this.cols = c;
		this.obstacles = obs;
	}

	/**
	 * Genera una descripcion textual del juego.
	 */
	@Override
	public String gameDesc() {
		return "Ataxx: a board game for Atari guys of the nineties.";
	}

	/**
	 * Proporciona el numero maximo de jugadores permitido para este juego.
	 */
	@Override
	public int maxPlayers() {
		return 4;
	}
	
	/**
	 * Devuelve el estado del juego según las reglas del juego 
	 * y el tablero dado: si ha terminado con un ganador, en tablas, 
	 * si no ha terminado. Si hay ganador, tambien devuelve la ficha ganadora.
	 */
	@Override
	public Pair<State, Piece> updateState(Board board,
			List<Piece> playersPieces, Piece lastPlayer){

		if(board.isFull()){
			return isPlayerWon(board, playersPieces);
		}else if(isNotMove(board, playersPieces)){
			return isPlayerWon(board, playersPieces);
		}
		else{
			Piece p = null;
			int cont = 0;
			for (int i = 0; i < rows; i++) {
				for (int j = 0; j < cols; j++) {
					if(playersPieces.contains(board.getPosition(i, j))){
						if(board.getPosition(i, j) != p){
							p = board.getPosition(i, j);
							cont++;
						}
					}
				}
			}
			if (cont == 1){
				return new Pair<State, Piece>(State.Won,p);
			}
			else{
				return gameInPlayResult;
			}
		}		
	}
	/**
	 * Indica quien ha sido el ganador o si ha habido empate
	 * @param board = el tablero
	 * @param playersPieces = los jugadores(fichas)
	 * @return
	 */
	private Pair<State, Piece> isPlayerWon(Board board, List<Piece> playersPieces) {
		Iterator<Piece> it = playersPieces.iterator();
		int max = 0;
		Piece ganador = null;
		boolean draw = false;
		while(it.hasNext()){
			Piece p = it.next();
			int pieces = board.getPieceCount(p);
			if (pieces > max){
				ganador = p;
				max = pieces;
				draw = false;
			}else if(pieces == max){
				draw = true;
			}
		}
		if (draw == true){
			return new Pair<State, Piece>(State.Draw, null);
		}else{
			return new Pair<State, Piece>(State.Won, ganador);
		}
	}
	/**
	 * Comprueba que ningun jugador puede mover. Devuelve true si ninguno puede 
	 * y false si alguno puede mover
	 * @param board = tablero
	 * @param playersPieces = las fichas de los jugadores
 	 * @return
	 */
	public boolean isNotMove(Board board, List<Piece> playersPieces) {
		Iterator<Piece> it = playersPieces.iterator();
		int players = 0;
		while(it.hasNext()){
			Piece p = it.next();
			List<GameMove> validos = validMoves(board, playersPieces, p);
			int movs = validos.size();
			if(movs == 0){
				players++;
			}
		}
		return playersPieces.size() == players;
	}
	/**
	 * Crea el tablero inicial segun las reglas del juego.
	 */
	@Override
	public Board createBoard(List<Piece> pieces) {
		Board b = new FiniteRectBoard(rows, cols);
		Piece obs = new Piece("*");
		Iterator<Piece> it = pieces.iterator();
		Piece piece = it.next();
		b.setPosition(0, 0, piece);
		b.setPosition(rows -1, cols -1, piece);
		b.setPieceCount(piece, 2);
		piece = it.next();
		b.setPosition(0, cols -1, piece);
		b.setPosition(rows -1, 0, piece);
		b.setPieceCount(piece, 2);
		if(it.hasNext()){
			piece = it.next();
			b.setPosition(0, (cols -1) / 2, piece);
			b.setPosition(rows -1, (cols -1) / 2, piece);
			b.setPieceCount(piece, 2);
			if(it.hasNext()){
				piece = it.next();
				b.setPosition((rows -1) / 2, 0, piece);
				b.setPosition((rows -1) / 2, cols -1, piece);
				b.setPieceCount(piece, 2);
			}
		}
		int i = pieces.size();
		int n = obstacles;
		int j = rows * cols - i * 2;
		if ( n > j) {
			n = j;
			System.out.println("The number of the obstacles changed.They can be only " + j);
		}
		while(n != 0){
			if(b.isFull()){
				n = 0;
			}
			int r = Utils.randomInt(rows);
			int c = Utils.randomInt(cols);
			if(b.getPosition(r, c) == null){
				b.setPosition(r, c, obs);
				n--;
			}
		}
		return b;	
	}

	/**
	 * Proporciona el jugador inicial segun las reglas del juego.
	 */
	@Override
	public Piece initialPlayer(Board board, List<Piece> pieces) {
		return pieces.get(0);
	}

	/**
	 * Proporciona el numero minimo de jugadores permitido para este juego.
	 */
	@Override
	public int minPlayers() {
		return 2;
	}

	/**
	 * Devuelve el siguiente jugador.
	 */
	@Override
	public Piece nextPlayer(Board board, List<Piece> playersPieces, Piece lastPlayer) {
		List<Piece> pieces = playersPieces;
		int i = pieces.indexOf(lastPlayer);
		Piece nextPlayer = null;
		boolean next = false;
		while(next == false){
			Piece p = pieces.get((i + 1) % pieces.size());
			List<GameMove> validos = validMoves(board, playersPieces, p);
			int n = validos.size();
			i++;
			if(n > 0){
				nextPlayer = p;
				next = true;
			}
		}
		return nextPlayer;
	}

	/**
	 * Evalua la proximidad del jugador que juega con la ficha turn de ganar (1) 
	 * o de perder (-1). Debe usarse para implementar estrategias de IA. 
	 * Al menos, si no hay ningun algoritmo de evaluacion del movimiento, 
	 * debe devolver el valor neutral 0.
	 */
	@Override
	public double evaluate(Board board, List<Piece> pieces, Piece turn, Piece p) {
		// TODO Auto-generated method stub
		return 0;
	}
	/**
	 * Genera una lista de movimientos validos o null si no se permite esta operacion.
	 */
	@Override
	public List<GameMove> validMoves(Board board, List<Piece> playersPieces,
			Piece turn) {
		List<GameMove> moves = new ArrayList<GameMove>();
		int r = board.getRows();
		int c = board.getCols();
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				Piece p = board.getPosition(i, j);
				if (p != null){
					if (turn.equals(p)) {
						
						for(int k = i - 2; k <= i + 2; k++) {
							for(int l = j - 2; l <= j + 2; l++) {
								if (k >= 0 && k < r && l >= 0 && l < c && board.getPosition(k, l) == null) {
									moves.add(new AtaxxMove(k, l, i, j, turn));
								}	
							}
						}
					}
				}
			}
		}
		return moves;
	}
}
	
