package es.ucm.fdi.tp.practica4.ataxx;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import es.ucm.fdi.tp.basecode.bgame.control.ConsolePlayer;
import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.DummyAIPlayer;
import es.ucm.fdi.tp.basecode.bgame.control.GameFactory;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.AIAlgorithm;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.views.GenericConsoleView;


/**
 * A Factory for Ataxx. 
 * 
 * <p>
 * Factoría del juego Ataxx.Es un nuevo juego donde hay minimo 2 jugadores cada uno con fichas 
 * de un color distinto y podran mover sus fichas a una distancia maxima de 2 casillas de distancia
 */
public class AtaxxFactory implements GameFactory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int rows;
	private int cols;
	private int obstacles;
	
	/**
	 * El constructora por defecto del tablero si no se introducen filas,columnas y obstaculos
	 */
	public AtaxxFactory() {
		this(7,7,0);
	}
	
	/**
	 * La constructora que crear un tablero con r filas,c columnas y 0 obstaculos
	 * @param r = numero de filas
	 * @param c = numero de columnas
	 */
	public AtaxxFactory(int r, int c) {
		this(r,c,0);
	}
	
	/**
	 * La constructora que crear un tablero o obstaculos
	 * @param o = numero de obtaculos
	 */
	public AtaxxFactory(int o) {
		this(7,7,o);
	}
	
	/**
	 * La constructora que crea un tablero con r filas, c columnas y obs obstaculos
	 * @param r = numero de filas
	 * @param c = numero de columnas
	 * @param obs = numero de obstaculos
	 */
	public AtaxxFactory(int r, int c, int obs){
		if (r < 5 || c < 5) {
			throw new GameError("Dimension must be at least 5: " + r + "x" + c);
		} else {
			if(r % 2 != 1 || c % 2 != 1){
				throw new GameError("Dimension must be a pair number: " + r + "x" + c);
			} else {
				int x =r * c;
				if(obs > x){
					throw new GameError("Obstacles must be less then: " + r * c);
				} else {
					this.rows = r;
					this.cols = c;
					this.obstacles = obs;
				}
			}
		}
	}
	
	/**
	 * Crea las reglas del juego
	 */
	@Override
	public GameRules gameRules() {
		return new AtaxxRules(rows,cols,obstacles);
	}

	/**
	 * Crea un jugador de consola para el juego
	 */
	@Override
	public Player createConsolePlayer() {
		ArrayList<GameMove> possibleMoves = new ArrayList<GameMove>();
		possibleMoves.add(new AtaxxMove());
		return new ConsolePlayer(new Scanner(System.in), possibleMoves);
	}

	/**
	 * By default, we have two player X and O.
	 * <p>
	 * Por defecto, dos jugadores, X y O.
	 */
	@Override
	public List<Piece> createDefaultPieces() {
		List<Piece> pieces = new ArrayList<Piece>();
		pieces.add(new Piece("X"));
		pieces.add(new Piece("O"));
		return pieces;
	}

	/**
	 * Crea un jugador aleatorio para el juego
	 */
	@Override
	public Player createRandomPlayer() {
		return new AtaxxRandomPlayer();
	}

	/**
	 * Crea un jugador automatico para el juego
	 */
	@Override
	public Player createAIPlayer(AIAlgorithm alg) {
		return new DummyAIPlayer(createRandomPlayer(), 1000);
	}

	/**
	 * Crea una vista de consola y la conecta al juego game y al controlador ctrl.
	 */
	@Override
	public void createConsoleView(Observable<GameObserver> game, Controller ctrl) {
		new GenericConsoleView(game, ctrl);
	}

	/**
	 * Crea una vista GUI y la conecta al juego game y al controlador ctrl.
	 *  El parametro viewPiece indica la ficha a la que pertenece la vista 
	 *  (cuando es null, se utiliza la misma vista para todas las fichas).
	 *   Los parametros randPlayer y {code aiPlayer} se deben utilizar en 
	 *   la vista para generar movimientos aleatorios y automaticos.
	 */
	@Override
	public void createSwingView(Observable<GameObserver> game, Controller ctrl,
			Piece viewPiece, Player randPlayer, Player aiPlayer) {
		throw new UnsupportedOperationException("There is no swing view");		
	}
}
