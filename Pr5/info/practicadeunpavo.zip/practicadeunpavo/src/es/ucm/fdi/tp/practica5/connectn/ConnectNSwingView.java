package es.ucm.fdi.tp.practica5.connectn;

import com.sun.corba.se.spi.ior.MakeImmutable;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.practica5.views.RectBoardSwingView;

public class ConnectNSwingView extends RectBoardSwingView{
	
	private static final long serialVersionUID = 1L;
	private ConnectNSwingPlayer player;
	
	public ConnectNSwingView(Observable<GameObserver> g, Controller c,
			Piece localPiece, Player randPlayer, Player aiPlayer) {
		super(g, c, localPiece, randPlayer, aiPlayer);
		player = new ConnectNSwingPlayer();
	}

	@Override
	protected void handleMouseClick(int row, int col, int mouseButton) {
		// TODO Auto-generated method stub
		if (mouseButton == 1){
	//	addM
		}
		decideMakeManualMove(player);
		
	}

	@Override
	protected void activateBoard() {
		// TODO Auto-generated method stub
		this.enableView();
	}

	@Override
	protected void deActivateBoard() {
		// TODO Auto-generated method stub
		this.disableView();
	}

}
