package es.ucm.fdi.tp.practica5.connectn;

import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.GameRules;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public class ConnectNSwingPlayer  extends Player {

	private static final long serialVersionUID = 1L;

	@Override
	public GameMove requestMove(Piece p, Board board, List<Piece> pieces, GameRules rules) {
		
		List<GameMove> availableMoves = rules.validMoves(board, pieces, p);
		if (availableMoves == null) {
			throw new UnsupportedOperationException(
					"The game '" + rules.gameDesc() + "' does not support the generation of valid moves.");
		}
		
		return null;
	}

}
