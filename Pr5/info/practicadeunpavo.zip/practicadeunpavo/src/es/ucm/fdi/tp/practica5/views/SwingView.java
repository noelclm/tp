package es.ucm.fdi.tp.practica5.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import com.sun.media.jfxmedia.events.PlayerTimeListener;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;
import es.ucm.fdi.tp.basecode.bgame.model.Game.State;
import es.ucm.fdi.tp.extra.jcolor.ColorChooser;
import es.ucm.fdi.tp.practica5.Main.PlayerMode;

public abstract class SwingView extends JFrame implements GameObserver {

	private static final long serialVersionUID = 1L;
	private Observable<GameObserver> game;
	private Controller ctrl;
	protected Piece localPiece;
	private Piece turn;
	protected Board board;
	protected List<Piece> pieces;
	private Map<Piece, Color> pieceColors;
	private Map<Piece, PlayerMode> playerTypes;
	private JPanel mainPanel;
	private JPanel ctrlPanel;
	private JPanel boardPanel;
	private Player ramdomPlayer;
	private Player aiPlayer;
	private JTextArea mensaje;
	private PlayerInfoTableModel playerInfoTable;
	JComboBox<Piece> pieceColorComboBox;
	JComboBox<Piece> piecePlayerModeComboBox;
	JComboBox<PlayerMode> playerModeComboBox;
	Iterator<Color> colorsIter;
	boolean inPlay;
	
	public enum PlayerMode {
		MANUAL("Manual"), RANDOM("Random"), AI("Automatics");

		private String desc;

		PlayerMode( String desc) {
		
			this.desc = desc;
		}

		@Override
		public String toString() {
			return desc;
		}
	}
	
	public class PlayerInfoTableModel extends AbstractTableModel {

		private static final long serialVersionUID = 1L;
		private String[] colNames;
		
		PlayerInfoTableModel(){
			this.colNames = new String[] {"Player","Mode","Pieces"};
		}
		public String getColumnNames(int col) {
			return colNames[col];
		}
		public int getColumnCount(){
			return colNames.length;
		}
		@Override
		public int getRowCount(){
			return pieces == null ? 0 : pieces.size();
		}
		
		public void refresh() {
			fireTableStructureChanged();
		}
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			switch (columnIndex) {
			case 0:
				return pieces.get(rowIndex);
			case 1:
				return playerTypes.get(pieces.get(rowIndex));
			case 2:
				return board.getPieceCount(pieces.get(rowIndex));
			default:
				break;
			}
			return columnIndex;
		}
	}

	public SwingView(Observable<GameObserver> g, Controller c, Piece localPiece, Player randPlayer, Player aiPlayer) {
		
		this.game = g;
		this.ctrl = c;
		this.localPiece = localPiece;
		this.ramdomPlayer = randPlayer;
		this.aiPlayer = aiPlayer;
		pieceColors = new HashMap<Piece, Color>();
		playerTypes = new  HashMap<Piece, PlayerMode>();
		boolean inPlay = false;
		
		colorsIter = new Iterator<Color>() {

			@Override
			public boolean hasNext() {
				return false;
			}

			@Override
			public Color next() {
				return null;
			}
		};
		initGUI();
		g.addObserver(this);
	}
	
	private void initGUI() { 
		mainPanel = new JPanel( new BorderLayout());
		boardPanel = new JPanel(new BorderLayout());
		ctrlPanel = new JPanel();
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		ctrlPanel.setLayout( new BoxLayout(ctrlPanel, BoxLayout.Y_AXIS));
		
		
		statusMessages();
		playerInformation();
		pieceColor();
		playerModes();
		AutomaticMoves();
		quitRestart();

		mainPanel.add(boardPanel, BorderLayout.CENTER);
		mainPanel.add(ctrlPanel, BorderLayout.LINE_END);
		this.getContentPane().add(mainPanel);
		initBoardGui(); 
		this.setMinimumSize(new Dimension(800, 400));
		this.setVisible(true);
		this.pack();
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent arg0){
				quit();
			}
		});
	}

	private void statusMessages() {
		JPanel statusMensajes = new JPanel( new BorderLayout());
		statusMensajes.setBorder( BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.BLACK), "Status Messages"));
		mensaje= new JTextArea();
		mensaje.setEditable(false);
		mensaje.setLineWrap(true);
		mensaje.setWrapStyleWord(true);
		JScrollPane jp = new JScrollPane(mensaje, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		statusMensajes.add(jp);
		statusMensajes.setPreferredSize(new Dimension(100,100));
		ctrlPanel.add(statusMensajes);
	}
	final protected void playerInformation() {
		JPanel playerInformation = new JPanel( new BorderLayout());
		playerInformation.setBorder( BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.BLACK), "Player Information"));
		
		playerInfoTable = new PlayerInfoTableModel();
		JTable tabla = new JTable(playerInfoTable){

			private static final long serialVersionUID = 1L;

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int col){
				Component comp =  super.prepareRenderer(renderer, row, col);
				Color c = pieceColors.get(pieces.get(row));
				 comp.setBackground(c);
				return  comp;
			}
		};
		
		JScrollPane jp = new JScrollPane(tabla);
		tabla.setFillsViewportHeight(true);
		playerInformation.setPreferredSize(new Dimension(100,100));
		playerInformation.add(jp);
		ctrlPanel.add(playerInformation);		
		
	}
	private void pieceColor() {
		JPanel pieceColor = new JPanel ();
		pieceColor.setBorder( BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.BLACK), "Piece Color"));
		pieceColorComboBox = new JComboBox<Piece>();

		JButton choose = new JButton("Choose Color");
		choose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){ choose(); }
		});

		pieceColor.add(pieceColorComboBox);
		pieceColor.add(choose);
		ctrlPanel.add(pieceColor);
		
	}
	protected void choose() {
		Piece p = (Piece) this.pieceColorComboBox.getSelectedItem();
		ColorChooser c = new ColorChooser(new JFrame(), "Select color", pieceColors.get(p));
		Color color = c.getColor();
		if ( color != null ) {
			pieceColors.put(p,color);
			this.actualizarTabla();
		}
	}
	private void playerModes() {
		JPanel playerModes = new JPanel ();
		
		playerModes.setBorder( BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.BLACK), "Player Modes"));
		piecePlayerModeComboBox = new JComboBox<Piece>();
		playerModeComboBox = new JComboBox<PlayerMode>();
		JButton set = new JButton("Set");
		set.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){ set();}
		});
		this.playerModeComboBox.addItem(PlayerMode.MANUAL);
		this.playerModeComboBox.addItem(PlayerMode.RANDOM);
		this.playerModeComboBox.addItem(PlayerMode.AI);
		playerModes.add(piecePlayerModeComboBox);
		playerModes.add(playerModeComboBox);
		
		playerModes.add(set);
		ctrlPanel.add(playerModes);
	}
	protected void set() {
		Piece p = (Piece) piecePlayerModeComboBox.getSelectedItem();
		PlayerMode pm = (PlayerMode) playerModeComboBox.getSelectedItem();
		playerTypes.put(p,pm);
		this.actualizarTabla();
		//Piece p = (Piece) this.playerModeComboBox.getSelectedItem();
		
	}
	private void AutomaticMoves() {
		JPanel automaticMoves = new JPanel();
		automaticMoves.setBorder( BorderFactory.createTitledBorder( BorderFactory.createLineBorder(Color.BLACK), "Automatic Moves"));
		JButton ramdom = new JButton("Random");
		ramdom.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {ctrl.makeMove(ramdomPlayer);}
		});
		JButton intelligent = new JButton("Intelligent");
		intelligent.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){ ctrl.makeMove(aiPlayer);}
		});
		automaticMoves.add(ramdom);
		automaticMoves.add(intelligent);
		ctrlPanel.add(automaticMoves);
	}
	private void actualizarTabla(){
		playerInfoTable.refresh();
	}
	private void quitRestart() {
		JPanel quitRestart = new JPanel ();
		JButton quit = new JButton("Quit");
		quit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {quit();}
		});
		JButton restart = new JButton("Restart");
		restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){ ctrl.restart();
			mensaje.setText("");}
		});

		quitRestart.add(quit);
		quitRestart.add(restart);
		ctrlPanel.add(quitRestart);
	}

	private void quit(){
		int n = JOptionPane.showOptionDialog(new JFrame(),
				"Estas seguro de que quieres cerrar el juego�?", "Quit",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
				 if (n == 0) {
					try{
						 ctrl.stop();
						 System.exit(0); 
					}catch(GameError e){
						
					}
					 
				 }
	}

	final protected Piece getTurn() { return turn; }
	final protected Board getBoard() { return board; }
	//cambiado board por tipo list<pieces>
	final protected List<Piece> getPieces() { return pieces; }
	final protected Color getPieceColor(Piece p) { return pieceColors.get(p); }
	final protected Color setPieceColor(Piece p, Color c) { return pieceColors.put(p,c); }
	final protected void setBoardArea(JComponent c) { 
		boardPanel.add(c,BorderLayout.CENTER);
	}
	final protected void addMsg(String msg) { 
		mensaje.append(msg + '\n');
	}

	final protected void decideMakeManualMove(Player manualPlayer) {  }
	private void decideMakeAutomaticMove() {  }

	protected abstract void initBoardGui();
	protected abstract void activateBoard();
	protected abstract void deActivateBoard();
	protected abstract void redrawBoard();

	public void onGameOver(Board board, State state, Piece winner) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleGameOver(board, state, winner);}
		});
	}
	
	protected void handleGameOver(Board board, State state, Piece winner) {
		this.board = board;
		addMsg("Game Over!!");
		this.redrawBoard();
		addMsg("Game Status: " + state);
		if (state == State.Won) {
			addMsg("Winner: " + winner);
		}
	}

	@Override
	public void onGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleGameStart(board, gameDesc, pieces, turn);}
		});
	}
	protected void handleGameStart(Board board, String gameDesc, List<Piece> pieces, Piece turn) {
		this.board = board;
		this.pieces = pieces;
		this.turn = turn;
		this.inPlay = true;
		//ahora
		inicializePiecesColors();
		inicializePlayersTypes();
		disableView();
		handleTurnChange(turn);
		
		//antes
	    this.setTitle("Board Game: " + gameDesc + (localPiece == null ? " " : " (" + localPiece + " )" ));

		
		this.redrawBoard();
	}
	private void inicializePiecesColors() {
		pieceColorComboBox.removeAllItems();
		for(Piece p : pieces) {
			if(pieceColors.get(p) == null) {
				pieceColors.put(p, colorsIter.next());
			}
			this.pieceColorComboBox.addItem(p);
		}
	}
	private void inicializePlayersTypes() {
		if (this.piecePlayerModeComboBox == null){
			return;
		}
		if (localPiece == null){
			for (Piece p : pieces) {
				if(playerTypes.get(p) == null){
					playerTypes.put(p, PlayerMode.MANUAL);
					this.piecePlayerModeComboBox.addItem(p);
				}
			}
		}else{
			if(playerTypes.get(localPiece) == null){
				playerTypes.put(localPiece, PlayerMode.MANUAL);
				this.piecePlayerModeComboBox.addItem(localPiece);
			}
		}
	}
	protected void disableView() {
		this.boardPanel.setEnabled(false);
	}
	private void handleTurnChange(Piece turn2) {
		
	}
	@Override
	public void onMoveStart(Board board, Piece turn) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleMoveStart(board, turn);}
		});
	}
	protected void handleMoveStart(Board board2, Piece turn2) {
		//?????????????
	}
	@Override
	public void onMoveEnd(Board board, Piece turn, boolean success) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleMoveEnd(board, turn, success);}
		});
	}
	protected void handleMoveEnd(Board board2, Piece turn2, boolean success) {
		// TODO Auto-generated method stub
		//???????????????
	}
	@Override
	public void onChangeTurn(Board board, Piece turn) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleChangeTurn(board, turn);}
		});
	}
	protected void handleChangeTurn(Board board2, Piece turn2) {
		this.board = board2;
		this.turn = turn2;
		
		this.redrawBoard();
		addMsg("Turn for " + turn);
	}
	@Override
	public void onError(String msg) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {handleError(msg);}
		});
	}
	protected void handleError(String msg) {
		addMsg(msg);
	}

	protected void enableView() {
		this.boardPanel.setEnabled(true);
	}
}