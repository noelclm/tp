package es.ucm.fdi.tp.practica5.views;

import java.awt.Color;

import es.ucm.fdi.tp.basecode.bgame.control.Controller;
import es.ucm.fdi.tp.basecode.bgame.control.Player;
import es.ucm.fdi.tp.basecode.bgame.model.GameObserver;
import es.ucm.fdi.tp.basecode.bgame.model.Observable;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

public abstract class RectBoardSwingView extends SwingView{

	private static final long serialVersionUID = 1L;
	
	private BoardComponent boardComp;
	public RectBoardSwingView(Observable<GameObserver> g, Controller c,
			Piece localPiece, Player randPlayer, Player aiPlayer) {
		super(g, c, localPiece, randPlayer, aiPlayer);
	}

	protected void initBoardGui(){
		boardComp = new BoardComponent() {
			@Override
			protected void mouseClicked(int row, int col, int mouseButton) {
				handleMouseClick(row,col,mouseButton);			}
			@Override
			protected Color getPieceColor(Piece p) {
				return RectBoardSwingView.this.getPieceColor(p);
			// get the color from the colours table, and if not
			// available (e.g., for obstacles) set it to have a color
			};
			@Override
			protected boolean isPlayerPiece(Piece p) {
							return false;
			// return true if p is a player piece, false if not (e.g, an obstacle)
			};
		};
		setBoardArea(boardComp);
		
	}
	@Override
	protected void redrawBoard() {
		boardComp.redraw(getBoard());
	// ask boardComp to redraw the board
	}
	protected abstract void handleMouseClick(int row, int col, int mouseButton);
}
