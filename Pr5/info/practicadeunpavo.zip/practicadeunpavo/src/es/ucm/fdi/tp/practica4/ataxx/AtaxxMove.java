package es.ucm.fdi.tp.practica4.ataxx;

import java.util.Iterator;
import java.util.List;

import es.ucm.fdi.tp.basecode.bgame.model.Board;
import es.ucm.fdi.tp.basecode.bgame.model.GameError;
import es.ucm.fdi.tp.basecode.bgame.model.GameMove;
import es.ucm.fdi.tp.basecode.bgame.model.Piece;

/**
 * A Class representing a move for Ataxx.
 * 
 * <p>
 * Clase para representar un movimiento del juego Ataxx.
 * 
 */
public class AtaxxMove extends GameMove {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Fila en la cual se va a poner la ficha
	 */
	private int row;

	/**
	 * Columna en la cual se va a poner la ficha
	 */
	private int col;

	/**
	 * Fila en donde esta la ficha
	 */
	private int rowOrigen;
	
	/**
	 * Columna en donde esta la ficha
	 */
	private int colOrigen;

	/**
	 * This constructor should be used ONLY to get an instance of
	 * {@link AtaxxMove} to generate game moves from strings by calling
	 * {@link #fromString(String)}
	 * 
	 * <p>
	 * Solo se debe usar este constructor para obtener objetos de
	 * {@link AtaxxMove} para generar movimientos a partir de strings usando
	 * el metodo {@link #fromString(String)}
	 * 
	 */

	/**
	 * Numero de obstaculos que se van a colocar en el tablero
	 */
	int obstacles;
	
	/**
	 * Constructor por defecto
	 */
	public AtaxxMove() {
	}

	/**
	 * Constructs a move for placing a piece of the type referenced by {@code p}
	 * at position ({@code row},{@code col}).
	 * 
	 * <p>
	 * Construye un movimiento para colocar una ficha del tipo referenciado por
	 * {@code p} en la posicion ({@code row},{@code col}).
	 * 
	 * @param row
	 *            Number of row.
	 *            <p>
	 *            Numero de fila.
	 * @param col
	 *            Number of column.
	 *            <p>
	 *            Numero de columna.
	 * @param p
	 *            A piece to be place at ({@code row},{@code col}).
	 *            <p>
	 *            Ficha a colocar en ({@code row},{@code col}).
	 */
	public AtaxxMove(int row, int col,int rowO, int colO, Piece p) {
		super(p);
		this.row = row;
		this.col = col;
		this.rowOrigen = rowO;
		this.colOrigen = colO;
	}

	/**
	 * Ejecuta el movimiento en el tablero board con la lista de fichas pieces.
	 */
	@Override
	public void execute(Board board, List<Piece> pieces) {
		if(board.getPosition(rowOrigen, colOrigen) == this.getPiece()){
			if(board.getPosition(row, col) == null){	
				int dist1 = 0;
				int dist2 = 0;
				Piece piece;
				
				dist1 = Math.abs(this.row - this.rowOrigen);
				dist2 = Math.abs(this.col - this.colOrigen);
				piece = board.getPosition(rowOrigen, colOrigen);
				
				if ((dist1 == 2 && dist2 <= dist1) || (dist2 == 2 && dist1 <= dist2)) {
					board.setPosition(row, col, piece);
					board.setPosition(rowOrigen, colOrigen, null);
					changePieces(board,pieces, piece);
				}
				else if ((dist1 == 1 && dist2 <= dist1) || (dist2 == 1 && dist1 <= dist2)) {
					board.setPosition(row, col, piece);
					changePieces(board,pieces, piece);
					
				}
				else {
					throw new GameError("position (" + row + "," + col + ") is out of range");
				}
				countMoves(board,pieces);
			}else{
				throw new GameError("position (" + row + "," + col + ") is already occupied!");
			}
		}else{
			throw new GameError("position (" + rowOrigen + "," + colOrigen + ") is an invalid piece!");
		}
	}

	/**
	 * Contabiliza el numero de fichas
	 * @param board = el tablero
	 * @param pieces = los jugadores(fichas)
	 */
	private void countMoves(Board board, List<Piece> pieces) {
		Iterator<Piece> it =pieces.iterator();
		while(it.hasNext()){
			Piece p = it.next();
			board.setPieceCount(p, 0);
		}
		for (int i = 0; i < board.getRows(); i++) {
			for (int j = 0; j < board.getCols(); j++) {
				Piece p = board.getPosition(i, j);
				if(pieces.contains(p)){
					int n = board.getPieceCount(p);
					n++;
					board.setPieceCount(p, n);
				}
			}
		}
	}
	
	/**
	 * Cambia las fichas que estan alrededor al color de la actual
	 * @param board = el tablero
	 * @param pieces = los jugadores(fichas)
	 * @param piece = ficha
	 */
	public void changePieces(Board board, List<Piece> pieces, Piece piece) {
		for(int i = row -1; i <= row +1; i++) {
			for(int j = col - 1; j <= col + 1; j++) {
				if (i >= 0 && i < board.getRows() && j >= 0 && j < board.getCols()) {
					Piece p = board.getPosition(i, j);
					if(pieces.contains(p)) {
						board.setPosition(i, j, piece);
					}
				}
			}
		}		
	}

	/**
	 * This move can be constructed from a string of the form "row SPACE col"
	 * where row and col are integers representing a position.
	 * 
	 * <p>
	 * Se puede construir un movimiento desde un string de la forma
	 * "row SPACE col" donde row y col son enteros que representan una casilla.
	 */
	@Override
	public GameMove fromString(Piece p, String str) {
		String[] words = str.split(" ");
		if (words.length != 4) {
			return null;
		}

		try {
			int row, col, rowO, colO;
			rowO = Integer.parseInt(words[0]);
			colO = Integer.parseInt(words[1]);
			row = Integer.parseInt(words[2]);
			col = Integer.parseInt(words[3]);
			return createMove(row, col, rowO, colO, p);
		} catch (NumberFormatException e) {
			return null;
		}

	}

	/**
	 * Creates a move that is called from {@link #fromString(Piece, String)}.
	 * Separating it from that method allows us to use this class for other
	 * similar games by overriding this method.
	 * 
	 * <p>
	 * Crea un nuevo movimiento con la misma ficha utilizada en el movimiento
	 * actual. Llamado desde {@link #fromString(Piece, String)}; se separa este
	 * metodo del anterior para permitir utilizar esta clase para otros juegos
	 * similares sobrescribiendo este metodo.
	 * 
	 * @param row
	 *            Row of the move being created.
	 *            <p>
	 *            Fila del nuevo movimiento.
	 * 
	 * @param col
	 *            Column of the move being created.
	 *            <p>
	 *            Columna del nuevo movimiento.
	 */
	public GameMove createMove(int row, int col, int rowO, int colO, Piece p) {
		return new AtaxxMove(row, col, rowO, colO, p);
	}

	/**
	 * Genera un string que describe el movimiento
	 */
	@Override
	public String help() {
		return "Row and column for origin an for destination, separated by spaces (four numbers).";
	}

	/**
	 * Genera un string con la posicion donde se mueve la ficha
	 */
	@Override
	public String toString() {
		if (getPiece() == null) {
			return help();
		} else {
			return "Place a piece '" + getPiece() + "' at (" + row + "," + col + ")";
		}
	}
}
