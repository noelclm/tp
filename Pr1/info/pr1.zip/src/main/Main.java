package main;
import controlador.Controlador;

/**
 * PRACTICA 1 - Simulacion de un Mundo Celular Simple.
 * @author Noel Clemente Montero
 * @author Estefan�a Ortega �vila
 */

public class Main {
	
	public static void main (String[] args){
		
		Controlador c= new Controlador();
		c.simula();
		
	}

}
