package main;
import controlador.Controlador;

/**
 * PRACTICA 2 - Nuevas Células en Nuestro Mundo.
 * @author Noel Clemente Montero
 * @author Estefanía Ortega Ávila
 */

public class Main {
	
	public static void main (String[] args){
		
		Controlador c= new Controlador();
		c.simula();
		
	}

}
